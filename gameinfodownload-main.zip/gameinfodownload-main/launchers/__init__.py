"""Game launcher scanner modules"""
